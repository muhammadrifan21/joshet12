<?php 
$koneksi = mysqli_connect("localhost","id13364295_rifan","Ineuyasha13_","id13364295_muhammadrifan");

// Check connection
if (mysqli_connect_errno()){
	echo "Koneksi database gagal : " . mysqli_connect_error();
}
?>