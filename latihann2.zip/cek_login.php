<?php

// mengaktifkan session pada php
session_start();

// menghubungkan php dengan koneksi database
include 'koneksi.php';

// menangkap data yang dikirim dari form login
$username = $_POST['username'];
$password = $_POST['password'];
// $nama = $_POST['nama'];

// menyeleksi data user dengan username dan password yang sesuai
$login = mysqli_query($koneksi, "SELECT * from user where username='$username' AND password='$password'");
// menghitung jumlah data yang ditemukan
$cek = mysqli_num_rows($login);

// cek apakah username dan password ditemukan pada database
if($cek > 0){

  $data = mysqli_fetch_assoc($login);

  //cek jika user login sebagai admin
  if($data['id_level']=="1"){

    // buat session login dan username
    $_SESSION['username'] = $username;
    $_SESSION['id_level'] = "1";
    // $_SESSION['nama'] = $nama;
    // alihkan ke halaman dashboard admin
    header("location:dashboard.php");
    

  // cek jika user login sebagai wali kelas
  }else if($data['id_level']==2){

    // buat session login dan username
    $_SESSION['username'] = $username;
    $_SESSION['id_level'] = 2;
    // alihkan ke halaman dashboard wali kelas
    header("location:dashboard2.php");


  // cek jika user login sebagai guru
  }else if($data['id_level']==3){

    // buat session login dan username
    $_SESSION['username'] = $username;
    $_SESSION['id_level'] = 3;
    // alihkan ke halaman dashboard guru
    header("location:dashboard3.php");


  // cek jika user login sebagai siswa
  }else if($data['id_level']==4){

    // buat session login dan username
    $_SESSION['username'] = $username;
    $_SESSION['id_level'] = 4;
    // alihkan ke halaman dashboard siswa
    header("location:dashboard4.php");
  


  }else{

    // alihkan ke halaman login kembali
    echo "<script>window.alert('ID Level tidak terdaftar')
  window.location='index.php'</script>";
  }
  
}else{
  echo "<script>window.alert('Username atau Password salah')
  window.location='index.php'</script>";
}

?>