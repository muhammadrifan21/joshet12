<?php 
// koneksi database
include '../../koneksi.php';

// menangkap data id yang di kirim dari url
$id_kelas = $_GET['id_kelas'];


// menghapus data dari database
mysqli_query($koneksi,"DELETE FROM kelas WHERE id_kelas='$id_kelas'");

// mengalihkan halaman kembali ke index.php
// header("location:index2.php");
echo "<script>window.alert('Data berhasil dihapus')
window.location='index2.php'</script>";

?>