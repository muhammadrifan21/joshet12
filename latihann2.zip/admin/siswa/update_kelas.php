<?php 
// koneksi database
include '../../koneksi.php';

// menangkap data yang di kirim dari form
$id_kelas = $_POST['id_kelas'];
$nm_kelas = $_POST['nm_kelas'];
$tingkatan = $_POST['tingkatan'];
$keterangan = $_POST['keterangan'];
$id_jurusan = $_POST['id_jurusan'];
// update data ke database
$query =mysqli_query($koneksi,"UPDATE kelas SET id_jurusan='$id_jurusan', nm_kelas='$nm_kelas', tingkatan='$tingkatan', keterangan='$keterangan' where id_kelas='$id_kelas'") or die (mysqli_error($query));

echo "<script>window.alert('Data Berhasil Diubah')
window.location='index2.php'</script>";


// mengalihkan halaman kembali ke index.php
// header("location:index2.php");

?>