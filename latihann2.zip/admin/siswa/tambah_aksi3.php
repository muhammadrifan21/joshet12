<?php
include '../../koneksi.php';
$nm_jurusan           = $_POST['nm_jurusan'];
// query SQL untuk insert data
$cek = mysqli_num_rows(mysqli_query($koneksi, "SELECT * from jurusan where nm_jurusan='$nm_jurusan'"));
if ($cek > 0) {
    echo "<script>window.alert('Data Sudah Ada')
     window.location='index3.php'</script>";
} else {
    mysqli_query($koneksi, "INSERT INTO jurusan SET nm_jurusan='$nm_jurusan'");
    echo "<script>window.alert('Data Di Simpan')
    window.location='index3.php'</script>";
}

// mengalihkan ke halaman index.php
// header("location:index3.php");
?>