<?php
include '../../koneksi.php';


$nis = $_POST['nis'];
$nama = $_POST["nama"];
 $temp_lahir = $_POST["temp_lahir"];
 $tgl_lahir = $_POST["tgl_lahir"];
 $gender  = $_POST["gender"];
 $agama = $_POST["agama"];
 $alamat = $_POST["alamat"];
 $id_kelas = $_POST["id_kelas"];



// cek ubah foto
if (isset($_POST['ubah_foto'])) { //jika ceklis
  //ambil foto
  $nama_foto = $_FILES['foto']['name'];
  $tmp = $_FILES['foto']['tmp_name'];
  //rename
  $fotobaru = date('dmYHis') .$nama_foto;

  // path
  $path = "../../gambar/" . $fotobaru;


  // upload
  if (move_uploaded_file($tmp, $path)) { //cek gambar berhasil

    //nis
    $query = "SELECT * FROM siswa where nis='" . $nis . "'";
    $sql = mysqli_query($koneksi, $query);
    $data = mysqli_fetch_array($sql);


    //cek foto sebelumnya
    if (is_file("../../gambar/" . $data['foto']))
      unlink("../../gambar/" . $data['foto']); //hapus foto

    //proses ubah ke database
    $query = "UPDATE siswa SET id_kelas='$id_kelas', nis='$nis', nama='$nama', temp_lahir='$temp_lahir', tgl_lahir='$tgl_lahir', gender='$gender',agama ='$agama' ,alamat='$alamat', foto='$fotobaru' where nis='$nis'";
    $sql = mysqli_query($koneksi, $query); //execute query

    if ($sql) { //cek jika proses masuk ke databse
      echo "<script>window.alert('Data Sudah Diubah')</script>";
      echo "<script>window.location='index.php'</script>";
    } else {
      echo "<script>window.alert('Data Gagal Diubah')</script>";
      echo "<script>window.location='index.php'</script>";
    }
  } else {
    echo "<script>window.alert('Gambar gagal Diubah')</script>";
    echo "<script>window.location='index.php'</script>";
  }
} else {
  // jika tidak di ceklis
  $query = "UPDATE siswa SET id_kelas='$id_kelas', nis='$nis', nama='$nama', temp_lahir='$temp_lahir', tgl_lahir='$tgl_lahir', gender='$gender',agama ='$agama' ,alamat='$alamat' where nis='$nis'";

  $sql = mysqli_query($koneksi, $query); //execute query

  if ($sql) { //cek jika proses masuk ke databse
    echo "<script>window.alert('Data Sudah Diubah')</script>";
    echo "<script>window.location='index.php'</script>";
  } else {
    echo "<script>window.alert('Data Gagal Diubah')</script>";
    echo "<script>window.location='index.php'</script>";
  }
}
?>