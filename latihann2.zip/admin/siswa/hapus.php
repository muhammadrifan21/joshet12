<?php 
// koneksi database
include '../../koneksi.php';

// menangkap data id yang di kirim dari url
$id_siswa = $_GET['id_siswa'];


// menghapus data dari database
mysqli_query($koneksi,"DELETE FROM siswa WHERE id_siswa='$id_siswa'");

// mengalihkan halaman kembali ke index.php
// header("location:index.php");
echo "<script>window.alert('Data berhasil dihapus')
window.location='index.php'</script>";


?>