  <?php

  //query
  include '../../koneksi.php';
  $nis                           = $_POST["nis"];
  $nama                       = $_POST["nama"];
  $temp_lahir                    = $_POST["temp_lahir"];
  $tgl_lahir                   = $_POST["tgl_lahir"];
  $gender                          = $_POST["gender"];
  $agama                           = $_POST["agama"];
  $alamat                          = $_POST["alamat"];
  $id_kelas                        = $_POST["id_kelas"];

  $foto = $_FILES['file']['name'];
  $file_tmp = $_FILES['file']['tmp_name'];
  $path = "../../gambar/$foto";

  move_uploaded_file($file_tmp, $path);

  // var_dump($nama_file);
  // var_dump($file_tmp);

  //cara 2
  $cek = mysqli_num_rows(mysqli_query($koneksi, "SELECT * from siswa where nis='$nis'"));
  if ($cek > 0) {
    echo "<script>window.alert('NIS yang anda masukan sudah ada')
    window.location='tambah.php'</script>";
  } else {
    mysqli_query($koneksi, "INSERT INTO siswa SET nis='$nis', nama='$nama',  temp_lahir='$temp_lahir', tgl_lahir='$tgl_lahir', gender='$gender',agama='$agama', alamat='$alamat',  id_kelas='$id_kelas', foto='$foto'");
    echo "<script>window.alert('Data Di Simpan')
    window.location='index.php'</script>";
  }
  // mysqli_close($connect);



  // header("location:../table.php");

  ?>
     <!-- <?php 
          // include 'koneksi.php';
          // if(isset($_POST['simpan'])){
          //       $nis                           = $_POST["nis"];
          //       $nama                  		= $_POST["nama"];
          //       $temp_lahir                    = $_POST["temp_lahir"];
          //       $tgl_lahir                   = $_POST["tgl_lahir"];
          //       $gender                          = $_POST["gender"];
      		  //   $agama                           = $_POST["agama"];
          //       $alamat                          = $_POST["alamat"];
          //       $id_kelas                        = $_POST["id_kelas"];
          //       $nama_file = $_FILES["file"]["name"];
          //       $file_tmp = $_FILES['file']['tmp_name'];
          //       $path = "gambar/$nama_file";
          //       $x = explode('.', $nama_file);
          //       $ekstensi = strtolower(end($x));
          //       $ekstensi_diperbolehkan = array('png','jpg');
          //       if(in_array($ekstensi, $ekstensi_diperbolehkan) === true){      
          //       move_uploaded_file($file_tmp, $path);

             //    $ekstensi_diperbolehkan = array('png','jpg');
             //    $nama_file = $_FILES['file']['name'];
             //    $x = explode('.', $nama_file);
             //    $ekstensi = strtolower(end($x));
             //    $ukuran = $_FILES['file']['size'];
             //    $file_tmp = $_FILES['file']['tmp_name'];  
             // if(in_array($ekstensi, $ekstensi_diperbolehkan) === true){
             //  if($ukuran < 1044070){      
             //    move_uploaded_file($file_tmp, 'file/image'.$nama_file);
                // $cek = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM siswa WHERE nis='$nis'"));
                // if ($cek > 0) {
                //   echo "<script>window.alert('NIS yang Anda Masukan Sudah Ada');window.location='tambah.php'</script>";
                //   }else {
                //     $query = "INSERT INTO siswa SET nis='$nis', nama='$nama',  temp_lahir='$temp_lahir', tgl_lahir='$tgl_lahir', gender='$gender',agama='$agama', alamat='$alamat',  id_kelas='$id_kelas', foto='$nama_file'";
                //     mysqli_query($koneksi, $query) or die(mysqli_error($query));
                //     echo "<script>window.alert('Data Sudah Disimpan')</script>";
                    // echo "<script>window.location='index.php'</script>";
                  // }
                // }
              // }
             // }
           
          ?> -->