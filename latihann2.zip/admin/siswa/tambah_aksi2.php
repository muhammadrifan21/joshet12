<?php
include '../../koneksi.php';
$nm_kelas           = $_POST['nm_kelas'];
$tingkatan           = $_POST['tingkatan'];
$keterangan           = $_POST['keterangan'];
$id_jurusan			= $_POST['id_jurusan'];

$cek = mysqli_num_rows(mysqli_query($koneksi, "SELECT * from kelas where nm_kelas='$nm_kelas' AND tingkatan= '$tingkatan' AND id_jurusan='$id_jurusan'"));
if ($cek > 0) {
  echo "<script>window.alert('Data Sudah Ada')
    window.location='index2.php'</script>";
} else {
  mysqli_query($koneksi, "INSERT INTO kelas SET id_jurusan='$id_jurusan', nm_kelas= '$nm_kelas', tingkatan='$tingkatan', keterangan='$keterangan'");
  echo "<script>window.alert('Data Di Simpan')
    window.location='index2.php'</script>";
}

// mengalihkan ke halaman index.php
// header("location:index2.php");
?>