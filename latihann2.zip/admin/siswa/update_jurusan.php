<?php 
// koneksi database
include '../../koneksi.php';

// menangkap data yang di kirim dari form
$id_jurusan = $_POST['id_jurusan'];
$nm_jurusan = $_POST['nm_jurusan'];

// update data ke database
mysqli_query($koneksi,"UPDATE jurusan SET nm_jurusan='$nm_jurusan' where id_jurusan='$id_jurusan'") or die (mysqli_error($koneksi));

// mengalihkan halaman kembali ke index.php
// header("location:index3.php");
echo "<script>window.alert('Data Berhasil Diubah')
window.location='index3.php'</script>";


?>