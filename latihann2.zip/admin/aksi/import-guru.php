
<?php 
include '../../koneksi.php';
include "excel_reader2.php";
?>

<?php
$target = basename($_FILES['filesiswa']['name']) ;
move_uploaded_file($_FILES['filesiswa']['tmp_name'], $target);

chmod($_FILES['filesiswa']['name'],0777);

$data = new Spreadsheet_Excel_Reader($_FILES['filesiswa']['name'],false);
$jumlah_baris = $data->rowcount($sheet_index=0);

$berhasil = 0;
for ($i=2; $i<=$jumlah_baris; $i++){

	
	$kode_guru  = $data->val($i, 1);
	$nama_guru  = $data->val($i, 2);
	$nama_mapel  = $data->val($i, 3);
	$alamat = $data->val($i, 4);
	

	if( $kode_guru != "" && $nama_guru != "" && $nama_mapel != "" && $alamat != "" ){
	
		mysqli_query($koneksi,"INSERT into guru values('null','$kode_guru','$nama_guru','$nama_mapel','$alamat')");
		$berhasil++;
	}
}


unlink($_FILES['filesiswa']['name']);


header("location:index4.php?berhasil=$berhasil");
?>