<?php 
        include '../../koneksi.php';
        $no = 1;
        $data = mysqli_query($koneksi, "SELECT kelas.id_kelas, kelas.nm_kelas, kelas.tingkatan, kelas.keterangan, jurusan.nm_jurusan FROM kelas INNER JOIN jurusan ON kelas.id_jurusan = jurusan.id_jurusan");
    ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
    <center>
        <h2>Data Laporan Kelas</h2>
    </center>
<table border="1">
    <thead>
        <tr>
            <th>No</th> 
            <th>Nama Kelas</th>
            <th>Keterangan</th>
            <th>Program Keahlian</th>
        </tr>
        </thead>
        <?php
           while($d = mysqli_fetch_array($data)){
          ?>

            <tr>
                <td><?php echo $no++ ?></td>
                <td><?php echo $d['tingkatan']; ?> <?php echo $d['nm_kelas']; ?></td>
                <td><?php echo $d['keterangan']; ?></td>
                <td><?php echo $d['nm_jurusan']; ?></td>

            </tr>
                <?php 
        }
        ?>
    </table>   
    <script>
        window.print();
    </script>
</body>
</html>