 <?php 
        include '../../koneksi.php';
        $no = 1;
        $data = mysqli_query($koneksi,"SELECT * FROM mapel");
    ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
    <center>
        <h2>Data Laporan Mata Pelajaran</h2>
    </center>
<table border="1">
    <thead>
        <tr>
            <th>No</th> 
            <th>Nama Mata Pelajaran</th>
        </tr>
        </thead>
        <?php
           while($d = mysqli_fetch_array($data)){
          ?>

            <tr>
               <td><?php echo $no++ ?></td>
                <td><?php echo $d['nama_mapel']; ?></td>
            </tr>
                <?php 
        }
        ?>
    </table>   
    <script>
        window.print();
    </script>
</body>
</html>