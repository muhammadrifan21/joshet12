 <?php 
        include '../../koneksi.php';
        $no = 1;
        $data = mysqli_query($koneksi,"SELECT * FROM user");
    ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
    <center>
        <h2>Data Laporan Mata User</h2>
    </center>
<table border="1">
    <thead>
        <tr>
            <th>No</th> 
            <th>Username</th>
            <th>Password</th>
            <th>Nama</th>
            <th>Level</th>
        </tr>
        </thead>
        <?php
           while($d = mysqli_fetch_array($data)){
          ?>

            <tr>
               <td><?php echo $no++ ?></td>
                <td><?php echo $d['username']; ?></td>
                <td><?php echo $d['password']; ?></td>
                <td><?php echo $d['nama']; ?></td>
                <td><?php echo $d['id_level']; ?></td>
            </tr>
                <?php 
        }
        ?>
    </table>   
    <script>
        window.print();
    </script>
</body>
</html>