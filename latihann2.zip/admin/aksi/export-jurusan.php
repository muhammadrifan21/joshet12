<?php 
        include '../../koneksi.php';
        $no = 1;
        $data = mysqli_query($koneksi,"SELECT * FROM jurusan");
    ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	 <?php
header("Content-type: application/octet-stream");
header("Content-Disposition: attachment; filename=jurusan.xls");
header("Pragma: no-cache");
header("Expires: 0");
?>
<table border="1">
    <thead>
       <tr>
            <th>No</th> 
            <th>Nama Jurusan</th>
        </tr>
        </thead>
        <?php
           while($d = mysqli_fetch_array($data)){
          ?>

            <tr>
                <td><?php echo $no++ ?></td>
                <td><?php echo $d['nm_jurusan']; ?></td>
            </tr>
                <?php 
        }
        ?>
    </table>   
</body>
</html>