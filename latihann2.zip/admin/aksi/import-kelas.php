
<?php 
include '../../koneksi.php';
include "excel_reader2.php";
?>

<?php
$target = basename($_FILES['filesiswa']['name']) ;
move_uploaded_file($_FILES['filesiswa']['tmp_name'], $target);

chmod($_FILES['filesiswa']['name'],0777);

$data = new Spreadsheet_Excel_Reader($_FILES['filesiswa']['name'],false);
$jumlah_baris = $data->rowcount($sheet_index=0);

$berhasil = 0;
for ($i=2; $i<=$jumlah_baris; $i++){

	
	$nm_kelas  = $data->val($i, 1);
	$tingkatan  = $data->val($i, 2);
	$keterangan  = $data->val($i, 3);
	

	if( $nm_kelas != "" && $tingkatan != "" && $keterangan != "" ){
	
		mysqli_query($koneksi,"INSERT into siswa values('null','$nm_kelas','$tingkatan','$keterangan')");
		$berhasil++;
	}
}

unlink($_FILES['filesiswa']['name']);


header("location:index2.php?berhasil=$berhasil");
?>