<?php 
        include '../../koneksi.php';
        $no = 1;
        $data = mysqli_query($koneksi, "SELECT siswa.id_siswa, siswa.nis, siswa.nama, siswa.temp_lahir, siswa.tgl_lahir, siswa.agama, siswa.alamat, siswa.foto, kelas.nm_kelas, kelas.tingkatan, jurusan.nm_jurusan FROM siswa INNER JOIN kelas ON siswa.id_kelas = kelas.id_kelas INNER JOIN jurusan ON kelas.id_jurusan = jurusan.id_jurusan");
       
            ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	 <?php
header("Content-type: application/octet-stream");
header("Content-Disposition: attachment; filename=siswa.xls");
header("Pragma: no-cache");
header("Expires: 0");
?>
<table border="1">
    <thead>
        <tr>
            <th>No</th>
            <th>Nis</th>
            <th>Nama</th>
            <th>Tempat Tanggal Lahir</th>
            <th>Agama</th>
            <th>Alamat</th>
            <th>Kelas</th>
            <th>Program Keahlian</th>
        </tr>
        </thead>
        <?php
           while($d = mysqli_fetch_array($data)){
          ?>

            <tr>
                <td><?php echo $no++ ?></td>
                <td><?php echo $d['nis']; ?></td>
                <td><?php echo $d['nama']; ?></td>
                <td><?php echo $d['temp_lahir']; ?> <?php echo $d['tgl_lahir']; ?></td>
                <td><?php echo $d['agama']; ?></td>
                <td><?php echo $d['alamat']; ?></td>
                <td><?php echo $d['tingkatan']; ?> <?php echo $d['nm_kelas']; ?></td>
                <td><?php echo $d['nm_jurusan']; ?></td>
            </tr>
                <?php 
        }
        ?>
    </table>   
</body>
</html>