 <?php 
    include '../../koneksi.php';
    $no = 1;
    $data = mysqli_query($koneksi, "SELECT guru.id_guru, guru.kode_guru, guru.nama_guru, guru.foto, guru.alamat, mapel.nama_mapel FROM guru INNER JOIN mapel ON guru.id_mapel = mapel.id_mapel");
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
    <center>
        <h2>Data Laporan Guru</h2>
    </center>
<table border="1">
    <thead>
        <tr>
            <th>No</th> 
            <th>Kode Guru</th>
            <th>Nama Guru</th>
            <th>Foto</th>
            <th>Mapel</th>
            <th>Alamat</th>
        </tr>
        </thead>
        <?php
           while($d = mysqli_fetch_array($data)){
          ?>

            <tr>
               <td><?php echo $no++ ?></td>
                <td><?php echo $d['kode_guru']; ?></td>
                <td><?php echo $d['nama_guru']; ?></td>
                <td><?=
                                            "<img src='../../gambar/" . $d['foto'] . "' width='50' height='50'>";
                                          ?>
                                          <!-- Gagal Wae -->
                                          <!-- <img src="<?php echo "file/image/" .$d['foto'] ?>" width="100px" height="100px">
                                      </td> -->
                </td>
                <td><?php echo $d['nama_mapel']; ?></td>
                <td><?php echo $d['alamat']; ?></td>
                                      
            </tr>
                <?php 
        }
        ?>
    </table>   
    <script>
        window.print();
    </script>
</body>
</html>