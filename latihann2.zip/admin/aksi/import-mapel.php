
<?php 
include '../../koneksi.php';
include "excel_reader2.php";
?>

<?php
$target = basename($_FILES['filesiswa']['name']) ;
move_uploaded_file($_FILES['filesiswa']['tmp_name'], $target);

chmod($_FILES['filesiswa']['name'],0777);

$data = new Spreadsheet_Excel_Reader($_FILES['filesiswa']['name'],false);
$jumlah_baris = $data->rowcount($sheet_index=0);

$berhasil = 0;
for ($i=2; $i<=$jumlah_baris; $i++){

	
	$nama_mapel  = $data->val($i, 1);
	

	if( $nama_mapel != "" ){
	
		mysqli_query($koneksi,"INSERT into mapel values('null','$nama_mapel')");
		$berhasil++;
	}
}

unlink($_FILES['filesiswa']['name']);


header("location:index5.php?berhasil=$berhasil");
?>