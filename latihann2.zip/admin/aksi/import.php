<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<button><a href="../siswa/index.php">Kembali</a></button>
<br/><br/>
<?php 
include '../../koneksi.php';
?>
<table style="margin-left: 180px;">
<form method="post" enctype="multipart/form-data" action="import-siswa.php">
	Pilih File: 
	<input name="filesiswa" type="file" required="required"> 
	<input name="upload" type="submit" value="Import">
</form>
</table>
<br/><br/>

</body>
</html>