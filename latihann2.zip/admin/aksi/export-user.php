<?php 
         include '../../koneksi.php';
                                    $no = 1;
                                    $data = mysqli_query($koneksi, "SELECT user.id_user, user.username, user.password, user.nama, user.id_level, level.nama_level FROM user INNER JOIN level ON level.id_level = level.id_level");
    ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	 <?php
header("Content-type: application/octet-stream");
header("Content-Disposition: attachment; filename=user.xls");
header("Pragma: no-cache");
header("Expires: 0");
?>
<table border="1">
    <thead>
       <tr>
            <th>No</th> 
            <th>Username</th>
            <th>Password</th>
            <th>Nama</th>
            <th>Level</th>

        </tr>
        </thead>
        <?php
           while($d = mysqli_fetch_array($data)){
          ?>

            <tr>
                <td><?php echo $no++ ?></td>
                <td><?php echo $d['username']; ?></td>
                <td><?php echo $d['password']; ?></td>
                <td><?php echo $d['nama']; ?></td>
                <td><?php echo $d['id_level']; ?></td>
            </tr>
                <?php 
        }
        ?>
    </table>   
</body>
</html>