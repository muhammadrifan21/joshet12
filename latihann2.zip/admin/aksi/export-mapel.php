<?php 
        include '../../koneksi.php';
        $no = 1;
        $data = mysqli_query($koneksi,"SELECT * FROM mapel");
    ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	 <?php
header("Content-type: application/octet-stream");
header("Content-Disposition: attachment; filename=mapel.xls");
header("Pragma: no-cache");
header("Expires: 0");
?>
<table border="1">
    <thead>
       <tr>
            <th>No</th> 
            <th>Nama Mata Pelajaran</th>
        </tr>
        </thead>
        <?php
           while($d = mysqli_fetch_array($data)){
          ?>

            <tr>
                <td><?php echo $no++ ?></td>
                <td><?php echo $d['nama_mapel']; ?></td>
            </tr>
                <?php 
        }
        ?>
    </table>   
</body>
</html>