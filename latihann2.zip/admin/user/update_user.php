<?php 
// koneksi database
include '../../koneksi.php';

// menangkap data yang di kirim dari form
$id_user = $_POST['id_user'];
$username = $_POST['username'];
$password = $_POST['password'];
$nama = $_POST['nama'];
$id_level = $_POST['id_level'];

// update data ke database
mysqli_query($koneksi,"UPDATE user SET id_level='$id_level', username='$username', password='$password', nama='$nama' where id_user='$id_user'") or die (mysqli_error($koneksi));

// mengalihkan halaman kembali ke index.php
// header("location:index3.php");
echo "<script>window.alert('Data Berhasil Diubah')
window.location='index6.php'</script>";


?>