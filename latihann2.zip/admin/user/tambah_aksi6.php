<?php
include '../../koneksi.php';

 $username                           = $_POST["username"];
 $password                       = $_POST["password"];
 $nama                          = $_POST["nama"];
 $id_level                       = $_POST["id_level"];
// query SQL untuk insert data
$cek = mysqli_num_rows(mysqli_query($koneksi, "SELECT * from user where username='$username'"));
if ($cek > 0) {
    echo "<script>window.alert('Data Sudah Ada')
     window.location='index6.php'</script>";
} else {
    mysqli_query($koneksi, "INSERT INTO user SET username='$username', password='$password', nama='$nama', id_level='$id_level'");
    echo "<script>window.alert('Data Di Simpan')
    window.location='index6.php'</script>";
}

// mengalihkan ke halaman index.php
// header("location:index3.php");
?>