<?php
include '../../koneksi.php';
$nama_mapel           = $_POST['nama_mapel'];
// query SQL untuk insert data
$cek = mysqli_num_rows(mysqli_query($koneksi, "SELECT * from mapel where nama_mapel='$nama_mapel'"));
if ($cek > 0) {
    echo "<script>window.alert('Data Sudah Ada')
     window.location='index5.php'</script>";
} else {
    mysqli_query($koneksi, "INSERT INTO mapel SET nama_mapel='$nama_mapel'");
    echo "<script>window.alert('Data Di Simpan')
    window.location='index5.php'</script>";
}

// mengalihkan ke halaman index.php
// header("location:index3.php");
?>