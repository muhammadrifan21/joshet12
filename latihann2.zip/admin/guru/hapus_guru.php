<?php 
// koneksi database
include '../../koneksi.php';

// menangkap data id yang di kirim dari url
$id_guru = $_GET['id_guru'];


// menghapus data dari database
mysqli_query($koneksi,"DELETE FROM guru WHERE id_guru='$id_guru'");

// mengalihkan halaman kembali ke index.php
// header("location:index.php");
echo "<script>window.alert('Data berhasil dihapus')
window.location='index4.php'</script>";


?>