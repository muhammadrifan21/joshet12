<?php 
// koneksi database
include '../../koneksi.php';

// menangkap data yang di kirim dari form
$id_mapel = $_POST['id_mapel'];
$nama_mapel = $_POST['nama_mapel'];

// update data ke database
mysqli_query($koneksi,"UPDATE mapel SET nama_mapel='$nama_mapel' where id_mapel='$id_mapel'") or die (mysqli_error($koneksi));

// mengalihkan halaman kembali ke index.php
// header("location:index3.php");
echo "<script>window.alert('Data Berhasil Diubah')
window.location='index5.php'</script>";


?>